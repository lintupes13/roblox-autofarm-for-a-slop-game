**INSTALL THIS BELLOW!!!**

**python, from  https://www.python.org/downloads/windows/ and download from the stable releases not pre releases and pick the latest one either 32 bit or 64 bit, then select the add to path but NOT the no path limit while on the setup. Then open command prompt and paste these: pip install frida-tools**

**pip install psutil**

**pip install pygetwindow pyautogui**

**and: pip install mss opencv-python numpy**

**also keep the .png files DO NOT RENAME THEM only replace when you want to make it to detect any other items...**

**then restart ur pc (not requied but I recommend) then open the python file (you can check the .dll file with dnspy if you're suspicious**











**dnspy link: https://github.com/dnSpy/dnSpy/releases/tag/v6.1.8**



**Issues or game suggestions? add @linnunpes1 on discord**





**THIS AUTOFARM IS 100% UNDETECTED CUZ IT ISNT INJECTING ANYTHING AND MIGHT GET YOU BANNED IF MASS REPORTED**

**this autofarm is mostly for this roblox game:  https://www.roblox.com/games/140067658687251/Rope-an-Animal**

**cuz I hate these type of games.**

**the official link is a GitHub! if you got it from a other GitHub or other place like mediafire it might be a malware**

**the real link: https://github.com/lintupes13/roblox-autofarm-for-a-slop-game**

