import time
import cv2
import numpy as np
import os
import random
import ctypes
from mss import mss

# --- HARDWARE TIMING INTENSIFICATION ---
try:
    ctypes.windll.winmm.timeBeginPeriod(1)
except Exception:
    pass

try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass

PUL = ctypes.POINTER(ctypes.c_ulong)

class MouseInput(ctypes.Structure):
    _fields_ = [("dx", ctypes.c_long),
                ("dy", ctypes.c_long),
                ("mouseData", ctypes.c_ulong),
                ("dwFlags", ctypes.c_ulong),
                ("time", ctypes.c_ulong),
                ("dwExtraInfo", PUL)]

class Input_I(ctypes.Union):
    _fields_ = [("mi", MouseInput)]

class Input(ctypes.Structure):
    _fields_ = [("type", ctypes.c_ulong),
                ("ii", Input_I)]

extra = ctypes.c_ulong(0)
ii_down = Input_I()
ii_down.mi = MouseInput(0, 0, 0, 0x0002, 0, ctypes.pointer(extra))
CLICK_DOWN_PACKET = Input(ctypes.c_ulong(0), ii_down)

ii_up = Input_I()
ii_up.mi = MouseInput(0, 0, 0, 0x0004, 0, ctypes.pointer(extra))
CLICK_UP_PACKET = Input(ctypes.c_ulong(0), ii_up)

def hardware_move_to(x, y):
    total_hardware_x = int((x / 1550) * 65535)
    total_hardware_y = int((y / 1080) * 65535)
    ii_move = Input_I()
    ii_move.mi = MouseInput(total_hardware_x, total_hardware_y, 0, 0x0001 | 0x8000, 0, ctypes.pointer(extra))
    move_packet = Input(ctypes.c_ulong(0), ii_move)
    ctypes.windll.user32.SendInput(1, ctypes.pointer(move_packet), ctypes.sizeof(move_packet))

def execute_immediate_fast_click():
    # 1. IMMEDIATE DOWN STROKE
    ctypes.windll.user32.SendInput(1, ctypes.pointer(CLICK_DOWN_PACKET), ctypes.sizeof(CLICK_DOWN_PACKET))
    # 2. ACCELERATED HOLD TIME (Dropped from 0.10s to 0.02s for high-speed responsiveness)
    time.sleep(0.02)
    # 3. RELEASE
    ctypes.windll.user32.SendInput(1, ctypes.pointer(CLICK_UP_PACKET), ctypes.sizeof(CLICK_UP_PACKET))

def hardware_reset_center():
    center_hardware_x = int((775 / 1550) * 65535)
    center_hardware_y = int((540 / 1080) * 65535)
    ii_center = Input_I()
    ii_center.mi = MouseInput(center_hardware_x, center_hardware_y, 0, 0x0001 | 0x8000, 0, ctypes.pointer(extra))
    center_packet = Input(ctypes.c_ulong(0), ii_center)
    ctypes.windll.user32.SendInput(1, ctypes.pointer(center_packet), ctypes.sizeof(center_packet))

TOP_BAR_LIMIT = 140
TEMPLATE_FILES = ['target.png', 'target2.png', 'target3.png', 'target4.png']

# --- OPTIMIZATION: PRE-CONVERT TEMPLATES TO GRAYSCALE ---
PRELOADED_TEMPLATES = []
for filename in TEMPLATE_FILES:
    if os.path.exists(filename):
        # Reading as grayscale directly saves image dimension overhead
        img = cv2.imread(filename, cv2.IMREAD_GRAYSCALE)
        if img is not None:
            PRELOADED_TEMPLATES.append((img, img.shape[:2]))

is_chain_sweeping = False
monitor = {"top": TOP_BAR_LIMIT, "left": 0, "width": 1550, "height": 1080 - TOP_BAR_LIMIT}

def scan_and_process_live_frames(sct):
    global is_chain_sweeping
    
    try:
        sct_img = sct.grab(monitor)
    except Exception:
        return False
        
    # --- OPTIMIZATION: BGRA TO GRAYSCALE ---
    # Shifting from 3 channels (BGR) to 1 channel (Gray) speeds up matchTemplate by up to 300%
    screen_gray = cv2.cvtColor(np.array(sct_img), cv2.COLOR_BGRA2GRAY)
    found_targets = []
    
    for template, (t_h, t_w) in PRELOADED_TEMPLATES:
        result = cv2.matchTemplate(screen_gray, template, cv2.TM_CCOEFF_NORMED)
        yloc, xloc = np.where(result >= 0.74)
        
        # --- OPTIMIZATION: PIXEL CONSOLIDATION & NEIGHBOR FILTERING ---
        # Prevents processing 50 micro-points for the exact same target icon
        points = list(zip(xloc, yloc))
        if not points:
            continue
            
        # Quick filter grouping neighboring pixels (within half template size) together
        filtered_points = []
        while points:
            cx, cy = points.pop(0)
            filtered_points.append((cx, cy))
            points = [p for p in points if abs(p[0] - cx) > (t_w // 2) or abs(p[1] - cy) > (t_h // 2)]
            
        for x, y in filtered_points:
            found_targets.append((x + (t_w // 2), y + (t_h // 2) + TOP_BAR_LIMIT))
            
    if not found_targets:
        if is_chain_sweeping:
            hardware_reset_center()
            is_chain_sweeping = False
        return False
        
    if len(found_targets) >= 2:
        is_chain_sweeping = True
        
    target_x, target_y = random.choice(found_targets)
    
    # TELEPORT AND FIRE INSTANTLY
    hardware_move_to(target_x, target_y)
    execute_immediate_fast_click()
    
    if not is_chain_sweeping:
        hardware_reset_center()
        
    return True

if __name__ == "__main__":
    print("[ACTIVE] Optimized Grayscale Snap + 0.02s Hardware Hold initialized.")
    print("Running at ultra-fast processing speeds. Press Ctrl+C to close.")
    
    with mss() as sct:
        try:
            while True:
                scan_and_process_live_frames(sct)
        except KeyboardInterrupt:
            try:
                ctypes.windll.winmm.timeEndPeriod(1)
            except Exception:
                pass
            print("\nStopped.")
